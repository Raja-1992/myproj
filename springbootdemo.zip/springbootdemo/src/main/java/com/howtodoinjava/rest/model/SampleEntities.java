package com.howtodoinjava.rest.model;

import java.util.ArrayList;
import java.util.List;

public class SampleEntities
{
    private List<SampleEntity> SampleEntityList;
    
    public List<SampleEntity> getSampleEntityList() {
        if(SampleEntityList == null) {
        	SampleEntityList = new ArrayList<>();
        }
        return SampleEntityList;
    }
 
    public void setSampleEntityList(List<SampleEntity> SampleEntities) {
        this.SampleEntityList = SampleEntities;
    }
}
