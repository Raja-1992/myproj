package com.howtodoinjava.rest.dao;

import org.springframework.stereotype.Repository;
import com.howtodoinjava.rest.model.SampleEntities;
import com.howtodoinjava.rest.model.SampleEntity;

@Repository
public class SampleEntityDAO 
{
    private static SampleEntities list = new SampleEntities();
    
    static 
    {
        list.getSampleEntityList().add(new SampleEntity("111", "intelMapperApp", "red", "Kelos", "sen01", "rec01", "cor01","tran01","inbound","PayloadData","2020-01-26 13:50:21.007"));
        //list.getSampleEntityList().add(new SampleEntity(2, "Alex", "Kolenchiskey", "abc@gmail.com"));
       // list.getSampleEntityList().add(new SampleEntity(3, "David", "Kameron", "titanic@gmail.com"));
    }
    
    public SampleEntities getAllSampleEntity() 
    {
        return list;
    }
    
    public void addSampleEntity(SampleEntity SampleEntity) {
        list.getSampleEntityList().add(SampleEntity);
    }
}
