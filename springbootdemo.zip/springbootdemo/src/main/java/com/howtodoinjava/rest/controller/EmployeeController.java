package com.howtodoinjava.rest.controller;

import java.net.URI;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.howtodoinjava.rest.dao.SampleEntityDAO;
import com.howtodoinjava.rest.model.SampleEntity;
import com.howtodoinjava.rest.model.SampleEntities;

@RestController
@RequestMapping(path = "/entity")
public class EmployeeController 
{
    @Autowired
    private SampleEntityDAO SampleEntityDAO;
    
    @GetMapping(path="/get", produces = "application/json")
    public SampleEntities getEmployees() 
    {
        return SampleEntityDAO.getAllSampleEntity();
    }
    
    @PostMapping(path= "/add", consumes = "application/json", produces = "application/json")
    public ResponseEntity addEmployee(@RequestBody SampleEntity sampleentity) 
                 throws Exception 
    {       
        //Generate resource id
//        String id = SampleEntityDAO.getAllSampleEntity().getEmployeeList().size() + 1;
//        employee.setId(id);
        
        //add resource
        SampleEntityDAO.addSampleEntity(sampleentity);
        
        //Create resource location
        /*URI location = ServletUriComponentsBuilder.fromCurrentRequest()
                                    .path("/{id}")
                                    .buildAndExpand(sampleentity.getId())
                                    .toUri();*/
        
        //Send location in response
        return new ResponseEntity<>("Entity Created", HttpStatus.OK);
    }
}
