package com.howtodoinjava.rest.model;

import java.sql.Timestamp;

public class SampleEntity {


	private String processId;
    private String application;
    private String status;
    private String partnerName;
    private String senderId;
    private String receiverId;
    private String correlationId;
    private String transactionType;
    private String direction;
    private String payloadDetails;
    private String dateTime; 
   
    public SampleEntity() {
    }
    
    
 
    public SampleEntity(String processId, String application, String status, String partnerName, String senderId,
			String receiverId, String correlationId, String transactionType, String direction, String payloadDetails,
			String dateTime) {
		super();
		this.processId = processId;
		this.application = application;
		this.status = status;
		this.partnerName = partnerName;
		this.senderId = senderId;
		this.receiverId = receiverId;
		this.correlationId = correlationId;
		this.transactionType = transactionType;
		this.direction = direction;
		this.payloadDetails = payloadDetails;
		this.dateTime = dateTime;
	}






	public String getProcessId() {
		return processId;
	}






	public void setProcessId(String processId) {
		this.processId = processId;
	}






	public String getApplication() {
		return application;
	}






	public void setApplication(String application) {
		this.application = application;
	}






	public String getStatus() {
		return status;
	}






	public void setStatus(String status) {
		this.status = status;
	}






	public String getPartnerName() {
		return partnerName;
	}






	public void setPartnerName(String partnerName) {
		this.partnerName = partnerName;
	}






	public String getSenderId() {
		return senderId;
	}






	public void setSenderId(String senderId) {
		this.senderId = senderId;
	}






	public String getReceiverId() {
		return receiverId;
	}






	public void setReceiverId(String receiverId) {
		this.receiverId = receiverId;
	}






	public String getCorrelationId() {
		return correlationId;
	}






	public void setCorrelationId(String correlationId) {
		this.correlationId = correlationId;
	}






	public String getTransactionType() {
		return transactionType;
	}






	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}






	public String getDirection() {
		return direction;
	}






	public void setDirection(String direction) {
		this.direction = direction;
	}






	public String getPayloadDetails() {
		return payloadDetails;
	}






	public void setPayloadDetails(String payloadDetails) {
		this.payloadDetails = payloadDetails;
	}






	public String getDateTime() {
		return dateTime;
	}






	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}



	@Override
	public String toString() {
		return "SampleEntity [processId=" + processId + ", application=" + application + ", status=" + status
				+ ", partnerName=" + partnerName + ", senderId=" + senderId + ", receiverId=" + receiverId
				+ ", correlationId=" + correlationId + ", transactionType=" + transactionType + ", direction="
				+ direction + ", payloadDetails=" + payloadDetails + ", dateTime=" + dateTime + "]";
	}



    
}
